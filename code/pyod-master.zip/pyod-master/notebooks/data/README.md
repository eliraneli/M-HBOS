All datasets stored in this folder are downloaded from 
**Outlier Detection DataSets (ODDS)**: http://odds.cs.stonybrook.edu/#table1

If you use any data here, please see ODDS' citation policy:

Shebuti Rayana (2016).  ODDS Library [http://odds.cs.stonybrook.edu]. Stony Brook, NY: Stony Brook University, Department of Computer Science.